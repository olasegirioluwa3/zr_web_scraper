# Google Scraper Package

This package allows you to scrape Web search results using Python.
