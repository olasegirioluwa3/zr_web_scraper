from .scraper import AmazonScraper
